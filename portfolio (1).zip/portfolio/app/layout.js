import "./globals.css";
import { Ubuntu, Arvo } from "next/font/google";

const body = Ubuntu({ subsets: ["latin"], weight: ["300", "400", "500", "700"], variable: "--font-body" });
const logo = Arvo({ subsets: ["latin"], weight: ["700"], variable: "--font-logo" });

export const metadata = {
  title: "Urankhishig | Portfolio",
  description: "Portfolio of Urankhishig, a student from Mongolia interested in computer science and competitive programming.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={`${body.variable} ${logo.variable}`}>
      <body>{children}</body>
    </html>
  );
}
