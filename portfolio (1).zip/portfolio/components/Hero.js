import { site } from "@/data/content";

export default function Hero() {
  return (
    <section id="home" className="flex flex-col items-center px-6 pb-20 pt-4 text-center">
      <img src={site.avatar} alt={site.name} className="h-[120px] w-[120px] rounded-full bg-neutral-300 object-cover" />
      <h1 className="mt-8 text-3xl font-bold text-cream sm:text-4xl">
        Hi! I'm <span className="text-sage">{site.name}</span>, {site.tagline}
      </h1>
      <p className="mt-6 max-w-3xl text-sm text-mint">{site.heroText}</p>
      <div className="mt-6 flex gap-6">
        <a href="#contact" className="pill">Contact Me</a>
        <a href={site.resume} target="_blank" rel="noreferrer" className="pill">Resume</a>
      </div>
    </section>
  );
}
