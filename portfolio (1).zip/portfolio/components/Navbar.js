import { FaLinkedin } from "react-icons/fa";
import { site } from "@/data/content";

const links = [
  ["Home", "#home"],
  ["About Me", "#about"],
  ["Projects", "#projects"],
  ["Contact", "#contact"],
];

export default function Navbar() {
  return (
    <header className="sticky top-0 z-30 border-b border-white/10 bg-forest/95 backdrop-blur">
      <nav className="mx-auto flex h-14 max-w-6xl items-center justify-between px-6">
        <a href="#home" className="font-logo text-2xl text-card">{site.logo}</a>
        <ul className="hidden gap-6 text-sm sm:flex">
          {links.map(([label, href]) => (
            <li key={href}>
              <a href={href} className="text-mint transition hover:text-cream">{label}</a>
            </li>
          ))}
        </ul>
        <a href={site.linkedin} target="_blank" rel="noreferrer" className="pill text-xs sm:text-sm">
          <FaLinkedin className="text-base" /> Connect with Me
        </a>
      </nav>
    </header>
  );
}
