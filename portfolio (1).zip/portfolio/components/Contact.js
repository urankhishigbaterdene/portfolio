"use client";
import { useState } from "react";
import { FaEnvelope, FaPhoneAlt, FaMapMarkedAlt } from "react-icons/fa";
import { contact } from "@/data/content";

export default function Contact() {
  const [f, setF] = useState({ name: "", email: "", message: "" });
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  // Opens the visitor's mail app. To receive messages directly, swap this
  // for a Formspree / Resend endpoint later.
  const submit = (e) => {
    e.preventDefault();
    const subject = encodeURIComponent(`Portfolio message from ${f.name}`);
    const body = encodeURIComponent(`${f.message}\n\n${f.name} (${f.email})`);
    window.location.href = `mailto:${contact.email}?subject=${subject}&body=${body}`;
  };

  const input = "mt-1 w-full rounded-md bg-[#eadfca] px-3 py-2 text-sm text-ink placeholder:text-[#a0866a] outline-none focus:ring-2 focus:ring-sage";

  return (
    <section id="contact" className="px-6 py-16">
      <h2 className="section-title">Contact Me</h2>
      <div className="mx-auto mt-12 grid max-w-6xl items-center gap-12 md:grid-cols-2">
        <div>
          <h3 className="text-2xl font-bold text-sage">{contact.heading}</h3>
          <p className="mt-4 text-xs leading-relaxed text-mint">{contact.text}</p>
          <ul className="mt-6 space-y-4 text-xs text-mint">
            <li className="flex items-center gap-3"><FaEnvelope className="text-crimson" /> {contact.email}</li>
            <li className="flex items-center gap-3"><FaPhoneAlt className="text-crimson" /> {contact.phone}</li>
            <li className="flex items-center gap-3"><FaMapMarkedAlt className="text-crimson" /> {contact.location}</li>
          </ul>
        </div>
        <form onSubmit={submit} className="text-xs text-mint">
          <label className="block">Your Name
            <input required value={f.name} onChange={set("name")} placeholder="Enter your name" className={input} />
          </label>
          <label className="mt-4 block">Email
            <input required type="email" value={f.email} onChange={set("email")} placeholder="Enter your email" className={input} />
          </label>
          <label className="mt-4 block">Message
            <textarea required rows={5} value={f.message} onChange={set("message")} placeholder="Enter your message" className={input} />
          </label>
          <button type="submit" className="pill pill-sage mt-5 px-8">Send</button>
        </form>
      </div>
    </section>
  );
}
