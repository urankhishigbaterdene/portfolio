import { about, site } from "@/data/content";

export default function About() {
  return (
    <section id="about" className="px-6 py-16">
      <h2 className="section-title">A Bit More About Me!</h2>
      <div className="mx-auto mt-12 grid max-w-6xl items-center gap-10 md:grid-cols-[250px_1fr]">
        <img src={site.aboutImage} alt="" className="mx-auto h-[300px] w-[250px] rounded-sm object-cover" />
        <div className="text-sm leading-relaxed text-mint">
          <p>{about.paragraph}</p>
          <h3 className="mt-6 text-base font-bold text-mint">{about.readingTitle}</h3>
          <ul className="mt-3 list-disc space-y-1 text-center text-sm marker:text-cream">
            {about.reading.map((b) => (
              <li key={b.title} className="list-inside">
                <em>{b.title}</em> by {b.author}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}
