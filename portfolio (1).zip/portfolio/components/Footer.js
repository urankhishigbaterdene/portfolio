import { FaLinkedin, FaGithub } from "react-icons/fa";
import { footer, site } from "@/data/content";

export default function Footer() {
  return (
    <footer className="bg-[#eadfca] px-6 py-5 text-xs text-olive">
      <div className="mx-auto max-w-6xl">
        <div className="flex flex-col justify-between gap-3 sm:flex-row">
          <p className="font-serif text-xl font-bold text-crimson">{site.name}</p>
          <div className="sm:text-right">
            <p>{footer.line1}</p>
            <p>{footer.line2}</p>
          </div>
        </div>
        <hr className="my-3 border-olive" />
        <div className="flex flex-col items-center justify-between gap-3 sm:flex-row">
          <p>© {new Date().getFullYear()} {site.name}. All rights reserved.</p>
          <div className="flex gap-3 text-base">
            <a href={site.linkedin} target="_blank" rel="noreferrer" aria-label="LinkedIn"><FaLinkedin /></a>
            <a href={site.github} target="_blank" rel="noreferrer" aria-label="GitHub"><FaGithub /></a>
          </div>
          <p className="italic">This page was last updated {footer.updated}.</p>
        </div>
      </div>
    </footer>
  );
}
