/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,jsx}", "./components/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        forest: "#012e1f",
        cream: "#ecdfc8",
        sage: "#a3b36f",
        mint: "#a9dcd0",
        card: "#bddde8",
        ink: "#3a2200",
        olive: "#4b6b2f",
        crimson: "#b0003a",
      },
      fontFamily: {
        body: ["var(--font-body)", "system-ui", "sans-serif"],
        logo: ["var(--font-logo)", "Georgia", "serif"],
      },
    },
  },
  plugins: [],
};
