// ✏️ EDIT THIS FILE to make the site yours. Everything on the page comes from here.

export const site = {
  name: "Urankhishig",
  logo: "Urankhishig",
  tagline: "Aspiring Computer Scientist",
  heroText:
    "I'm a high school student from Ulaanbaatar, Mongolia, with a strong interest in algorithms, competitive programming and building things with code.",
  linkedin: "https://www.linkedin.com/in/your-handle", // TODO
  github: "https://github.com/your-handle", // TODO
  resume: "/resume.pdf", // put your PDF at public/resume.pdf
  avatar: "/images/avatar.svg", // replace with /images/avatar.jpg
  aboutImage: "/images/about.svg", // replace with /images/about.jpg
};

export const about = {
  paragraph:
    "I'm a high school student in Ulaanbaatar, Mongolia, passionate about computer science, informatics olympiads and hardware projects with Arduino and IoT. I enjoy solving hard problems, teaching others to code, and building tools that people actually use. Outside of tech, replace this with your hobbies.",
  readingTitle: "Currently Reading…",
  reading: [
    { title: "Book title one", author: "Author name" },
    { title: "Book title two", author: "Author name" },
  ],
};

export const projects = [
  {
    title: "Offline Judge",
    image: "/images/project-1.svg",
    tech: ["Programming", "Systems", "Competitive Programming"],
    description:
      "Replace with a 2–3 sentence description of what this project is, what problem it solves and what you built.",
    status: "Completed: describe the result, award or outcome here.",
    link: { label: "View on GitHub", href: "https://github.com/your-handle" },
  },
  {
    title: "Arduino IoT Project",
    image: "/images/project-2.svg",
    tech: ["Arduino", "C++", "IoT", "Sensors"],
    description: "Replace with a short description of your IoT project.",
    status: "Completed: describe the result here.",
    link: null,
  },
  {
    title: "Hackateen 2025 Project",
    image: "/images/project-3.svg",
    tech: ["Hackathon", "Teamwork"],
    description: "Replace with a short description of what your team built at Hackateen.",
    status: "Completed: describe the result here.",
    link: null,
  },
  {
    title: "She Can Code Teaching",
    image: "/images/project-4.svg",
    tech: ["Teaching", "Curriculum", "Python"],
    description: "Replace with a short description of what you taught and who you taught.",
    status: "Completed: describe the impact here.",
    link: null,
  },
  {
    title: "Informatics Olympiad Training",
    image: "/images/project-5.svg",
    tech: ["C++", "Algorithms", "Data Structures"],
    description: "Replace with a short description of your olympiad journey and what you learned.",
    status: "Ongoing: describe your current goals here.",
    link: null,
  },
  {
    title: "Personal Website",
    image: "/images/project-6.svg",
    tech: ["Next.js", "Tailwind CSS", "JavaScript"],
    description: "This portfolio, built with Next.js and Tailwind CSS and deployed on Vercel.",
    status: "Completed.",
    link: null,
  },
];

export const contact = {
  heading: "Let's Talk",
  text: "I am open to discussing new opportunities, collaborations, or simply chatting about common interests! Feel free to reach out to me through any of the following methods:",
  email: "you@example.com", // TODO
  phone: "+976 0000 0000", // TODO (or delete this line from Contact.js)
  location: "Ulaanbaatar, Mongolia",
};

export const footer = {
  line1: "High School Student | Ulaanbaatar, Mongolia",
  line2: "Passionate about coding, problem-solving, and innovation.",
  updated: "November 2026",
};
