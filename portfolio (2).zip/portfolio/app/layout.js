import "./globals.css";
import { Fredoka, Pacifico } from "next/font/google";

const body = Fredoka({ subsets: ["latin"], variable: "--font-body" });
const logo = Pacifico({ subsets: ["latin"], weight: "400", variable: "--font-logo" });

export const metadata = {
  title: "Urankhishig | Portfolio",
  description: "Portfolio of Urankhishig, a student from Mongolia who loves computer science and olympiads.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={`${body.variable} ${logo.variable}`}>
      <body>{children}</body>
    </html>
  );
}
