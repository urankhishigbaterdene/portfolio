// ✏️ EDIT THIS FILE to make the site yours. Everything on the page comes from here.

export const site = {
  name: "Urankhishig",
  logo: "Urankhishig",
  tagline: "Girl Coder & Olympiad Dreamer",
  heroText:
    "I'm a high school student from Ulaanbaatar, Mongolia, with a strong interest in algorithms, competitive programming and building things with code.",
  socials: {
    instagram: "https://instagram.com/your-handle", // TODO
    facebook: "https://facebook.com/your-handle", // TODO
    github: "https://github.com/urankhishigbaterdene",
    linkedin: "https://www.linkedin.com/in/your-handle", // TODO
  },
  avatar: "/images/avatar.svg", // replace with /images/avatar.jpg
  aboutImage: "/images/about.svg", // replace with /images/about.jpg
};

export const about = {
  paragraph:
    "I'm a high school student in Ulaanbaatar, Mongolia, passionate about computer science, informatics olympiads and hardware projects with Arduino and IoT. I enjoy solving hard problems, teaching others to code, and building tools that people actually use. Outside of tech, replace this with your hobbies.",
  readingTitle: "Currently Reading…",
  reading: [
    { title: "Book title one", author: "Author name" },
    { title: "Book title two", author: "Author name" },
  ],
};

export const projects = [
  {
    title: "Offline Judge",
    image: "/images/project-1.svg",
    tech: ["Programming", "Systems", "Competitive Programming"],
    description:
      "Replace with a 2–3 sentence description of what this project is, what problem it solves and what you built.",
    status: "Completed: describe the result, award or outcome here.",
    link: { label: "View on GitHub", href: "https://github.com/your-handle" },
  },
  {
    title: "Arduino IoT Project",
    image: "/images/project-2.svg",
    tech: ["Arduino", "C++", "IoT", "Sensors"],
    description: "Replace with a short description of your IoT project.",
    status: "Completed: describe the result here.",
    link: null,
  },
  {
    title: "Hackateen 2025 Project",
    image: "/images/project-3.svg",
    tech: ["Hackathon", "Teamwork"],
    description: "Replace with a short description of what your team built at Hackateen.",
    status: "Completed: describe the result here.",
    link: null,
  },
  {
    title: "She Can Code Teaching",
    image: "/images/project-4.svg",
    tech: ["Teaching", "Curriculum", "Python"],
    description: "Replace with a short description of what you taught and who you taught.",
    status: "Completed: describe the impact here.",
    link: null,
  },
  {
    title: "Informatics Olympiad Training",
    image: "/images/project-5.svg",
    tech: ["C++", "Algorithms", "Data Structures"],
    description: "Replace with a short description of your olympiad journey and what you learned.",
    status: "Ongoing: describe your current goals here.",
    link: null,
  },
  {
    title: "Personal Website",
    image: "/images/project-6.svg",
    tech: ["Next.js", "Tailwind CSS", "JavaScript"],
    description: "This portfolio, built with Next.js and Tailwind CSS and deployed on Vercel.",
    status: "Completed.",
    link: null,
  },
];

export const footer = {
  line1: "High School Student | Ulaanbaatar, Mongolia",
  line2: "Passionate about coding, problem-solving, and innovation.",
  updated: "November 2026",
};

export const recommendations = [
  {
    name: "Teacher Name One",
    role: "Informatics Teacher, Your School",
    photo: "/images/teacher-1.svg", // replace with /images/teacher-1.jpg
    quote:
      "Replace with a short quote from this teacher about you (2–3 sentences). Ask the teacher for permission before publishing it.",
  },
  {
    name: "Teacher Name Two",
    role: "Mathematics Teacher, Your School",
    photo: "/images/teacher-2.svg",
    quote: "Replace with a short quote from this teacher about you.",
  },
  {
    name: "Teacher Name Three",
    role: "Olympiad Coach, Your School",
    photo: "/images/teacher-3.svg",
    quote: "Replace with a short quote from this teacher about you.",
  },
];

export const awards = [
  { title: "Iranian Geometry Olympiad (IGO) 2025", medal: "Honorable Mention", img: "/images/cert-1.svg",
    text: "12th IGO, an international geometry competition for high school students from dozens of countries." },
  { title: "National Hackathon 2025 (Hackateen)", medal: "1st Place", img: "/images/cert-2.svg",
    text: "Built Hevug, a website for learning the Mongolian language. Won for educational impact, usability and innovation." },
  { title: "Battogtokh Scholarship 2026", medal: "Top 2", img: "/images/cert-3.svg",
    text: "One of the top two outstanding high school students nationwide for academics, leadership and potential in competitive programming." },
  { title: "Mongolian Informatics Olympiad 2025", medal: "6th Place", img: "/images/cert-4.svg",
    text: "Four online rounds plus one onsite final." },
  { title: "EGOI 2024 & 2026", medal: "Team Mongolia", img: "/images/cert-5.svg",
    text: "Selected twice as one of the top 4 girls in Mongolia through the National Girls' Olympiad in Informatics." },
]; // replace each img with a photo of your real certificate, e.g. /images/cert-1.jpg
