# Portfolio (Next.js + Tailwind)

## Run locally
    npm install
    npm run dev      # http://localhost:3000

## Edit
- All text/links/projects: `data/content.js`
- Photos: replace files in `public/images/` (and update paths in content.js)
- Resume: put `resume.pdf` in `public/`

## Deploy to Vercel
1. Push this folder to a GitHub repo.
2. vercel.com → Add New → Project → import the repo → Deploy.
(or: `npm i -g vercel && vercel --prod`)

## Recommendations
Edit teacher names, quotes and photos in `data/content.js` (`recommendations`) and put photos in `public/images/`.
