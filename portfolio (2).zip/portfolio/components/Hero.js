import { site } from "@/data/content";
import Flower from "./Flower";
import Pony from "./Pony";

export default function Hero() {
  return (
    <section id="home" className="relative flex flex-col items-center overflow-hidden px-6 pb-24 pt-10 text-center">
      <Flower size={110} className="absolute -left-6 top-4 animate-float" style={{ "--r": "-12deg" }} />
      <Flower size={70} a="#d9c6ff" b="#b99af2" className="absolute left-24 top-40 hidden animate-float sm:block" />
      <Flower size={120} a="#ffd6a8" b="#ffb26b" className="absolute -right-8 top-2 animate-float" style={{ "--r": "14deg" }} />
      <Flower size={60} className="absolute right-28 top-44 hidden animate-float sm:block" />
      <Pony className="absolute bottom-2 left-4 hidden animate-float lg:block" />
      <Pony body="#d9c6ff" mane="#ff8fbf" className="absolute bottom-2 right-4 hidden -scale-x-100 animate-float lg:block" />

      <div className="relative rounded-full border-4 border-white bg-gradient-to-br from-blush to-lav p-1 shadow-lg">
        <img src={site.avatar} alt={site.name} className="h-[130px] w-[130px] rounded-full bg-white object-cover" />
      </div>
      <h1 className="relative mt-8 font-logo text-3xl text-cream sm:text-4xl">
        Hi! I'm <span className="text-sage">{site.name}</span> ✨
      </h1>
      <p className="relative mt-2 text-xl font-medium text-ink">{site.tagline}</p>
      <p className="relative mt-5 max-w-2xl text-sm leading-relaxed">{site.heroText}</p>
      <div className="relative mt-7 flex gap-4">
        <a href="#projects" className="pill">See My Projects</a>
        <a href="#awards" className="pill">My Medals</a>
      </div>
    </section>
  );
}
