// Ranunculus: many layered, ruffled petals around a small center.
const ring = (n, d, rx, ry, fill, off = 0) =>
  Array.from({ length: n }, (_, i) => (
    <ellipse key={`${fill}${n}${i}`} cx="50" cy={50 - d} rx={rx} ry={ry} fill={fill}
      stroke="#fff" strokeOpacity=".55" strokeWidth="1.2" transform={`rotate(${(i * 360) / n + off} 50 50)`} />
  ));

export default function Flower({ size = 80, a = "#ffb3d1", b = "#ff8fbf", c = "#ffe27a", className = "", style }) {
  return (
    <svg viewBox="0 0 100 100" width={size} height={size} className={className} style={style} aria-hidden="true">
      {ring(10, 31, 13, 18, a)}
      {ring(8, 22, 11, 14, b, 20)}
      {ring(6, 13, 8, 10, a, 10)}
      {ring(4, 6, 5, 6, b, 30)}
      <circle cx="50" cy="50" r="4" fill={c} />
    </svg>
  );
}
