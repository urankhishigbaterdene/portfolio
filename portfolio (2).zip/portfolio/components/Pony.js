// Original pastel pony illustration (not a licensed character).
export default function Pony({ body = "#ffd1e6", mane = "#b388f5", width = 180, className = "", style }) {
  return (
    <svg viewBox="0 0 200 170" width={width} className={className} style={style} aria-hidden="true">
      <path d="M50 80C8 68 2 122 30 142C20 112 40 108 58 100Z" fill={mane} />
      {[55, 75, 118, 138].map((x) => <rect key={x} x={x} y="105" width="14" height="50" rx="7" fill={body} stroke="#fff" strokeWidth="2" />)}
      {[55, 75, 118, 138].map((x) => <rect key={"h" + x} x={x} y="146" width="14" height="9" rx="4" fill={mane} />)}
      <ellipse cx="100" cy="95" rx="56" ry="36" fill={body} stroke="#fff" strokeWidth="2" />
      <path d="M135 92L150 45L172 56L162 102Z" fill={body} />
      <ellipse cx="165" cy="50" rx="25" ry="22" fill={body} stroke="#fff" strokeWidth="2" />
      <ellipse cx="182" cy="61" rx="14" ry="11" fill={body} />
      <path d="M150 36L147 14L163 28Z" fill={body} stroke="#fff" strokeWidth="2" />
      <path d="M168 30L176 0L181 33Z" fill="#ffe27a" stroke="#fff" strokeWidth="1.5" />
      <path d="M152 30C118 28 116 72 140 98C128 72 150 62 166 44Z" fill={mane} />
      <ellipse cx="171" cy="48" rx="6.5" ry="8.5" fill="#fff" />
      <circle cx="172" cy="49.5" r="4.8" fill="#6b3a7d" />
      <circle cx="173.6" cy="46.8" r="1.9" fill="#fff" />
      <circle cx="179" cy="63" r="4.5" fill="#ff8fbf" opacity=".6" />
      <path d="M100 110C84 96 95 84 100 95C105 84 116 96 100 110Z" fill={mane} />
    </svg>
  );
}
