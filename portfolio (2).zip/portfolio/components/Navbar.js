import { site } from "@/data/content";
import Flower from "./Flower";

const links = [["Home", "#home"], ["About Me", "#about"], ["Projects", "#projects"], ["Awards", "#awards"], ["Recommendations", "#recommendations"]];

export default function Navbar() {
  return (
    <header className="sticky top-0 z-30 border-b-2 border-blush bg-white/90 backdrop-blur">
      <nav className="mx-auto flex h-14 max-w-6xl items-center justify-between px-6">
        <a href="#home" className="flex items-center gap-2 font-logo text-2xl text-cream">
          <Flower size={26} /> {site.logo}
        </a>
        <ul className="hidden gap-6 text-sm font-medium md:flex">
          {links.map(([l, h]) => (
            <li key={h}><a href={h} className="text-ink transition hover:text-sage">{l}</a></li>
          ))}
        </ul>
      </nav>
    </header>
  );
}
