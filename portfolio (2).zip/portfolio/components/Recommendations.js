import { recommendations } from "@/data/content";
import Flower from "./Flower";

export default function Recommendations() {
  return (
    <section id="recommendations" className="px-6 py-16">
      <h2 className="section-title">What My Teachers Say 💌</h2>
      <div className="mx-auto mt-10 grid max-w-6xl gap-6 md:grid-cols-3">
        {recommendations.map((r, k) => (
          <figure key={r.name} className="cute-card relative flex flex-col items-center p-6 pt-10 text-center">
            <Flower size={44} a={k % 2 ? "#d9c6ff" : "#ffb3d1"} b={k % 2 ? "#b99af2" : "#ff8fbf"} className="absolute -top-5 left-1/2 -translate-x-1/2" />
            <img src={r.photo} alt={r.name} className="h-24 w-24 rounded-full border-4 border-blush bg-white object-cover" />
            <blockquote className="mt-5 text-sm italic leading-relaxed text-olive">“{r.quote}”</blockquote>
            <figcaption className="mt-5">
              <p className="text-base font-bold text-ink">{r.name}</p>
              <p className="mt-1 text-xs text-olive">{r.role}</p>
            </figcaption>
          </figure>
        ))}
      </div>
    </section>
  );
}
