/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,jsx}", "./components/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        forest: "#fff3f8", cream: "#7b2d8e", sage: "#e0488f", mint: "#6a4a7a",
        card: "#ffffff", ink: "#4a2160", olive: "#7a5a8c", crimson: "#d6336c",
        lav: "#e6d8ff", blush: "#ffd6e8", pmint: "#cdf3e4",
      },
      fontFamily: {
        body: ["var(--font-body)", "system-ui", "sans-serif"],
        logo: ["var(--font-logo)", "cursive"],
      },
      keyframes: {
        float: { "0%,100%": { transform: "translateY(0) rotate(var(--r,0deg))" }, "50%": { transform: "translateY(-10px) rotate(var(--r,0deg))" } },
        flip: { from: { transform: "perspective(900px) rotateY(-80deg)", opacity: ".2" }, to: { transform: "perspective(900px) rotateY(0)", opacity: "1" } },
      },
      animation: { float: "float 5s ease-in-out infinite", flip: "flip .5s ease-out" },
    },
  },
  plugins: [],
};
