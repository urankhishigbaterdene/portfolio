"use client";
import { useEffect, useState } from "react";
import { projects } from "@/data/content";

export default function Projects() {
  const [active, setActive] = useState(null);

  useEffect(() => {
    const onKey = (e) => e.key === "Escape" && setActive(null);
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = active ? "hidden" : "";
    return () => window.removeEventListener("keydown", onKey);
  }, [active]);

  return (
    <section id="projects" className="px-6 py-16">
      <h2 className="section-title">My Projects</h2>
      <div className="mx-auto mt-10 grid max-w-6xl gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {projects.map((p) => (
          <article key={p.title} className="flex flex-col cute-card p-4 transition hover:-translate-y-1">
            <div className="flex h-[120px] items-center justify-center overflow-hidden rounded-md bg-white">
              <img src={p.image} alt="" className="h-full w-full object-cover" />
            </div>
            <h3 className="mt-5 text-lg font-bold leading-snug text-ink">{p.title}</h3>
            <p className="mt-2 text-xs text-olive">{p.tech.join(", ")}</p>
            <button onClick={() => setActive(p)} className="mt-auto pt-6 text-left text-xs text-crimson hover:underline">
              Read More
            </button>
          </article>
        ))}
      </div>

      {active && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4 backdrop-blur-md"
          onClick={() => setActive(null)}
          role="dialog"
          aria-modal="true"
          aria-label={active.title}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative max-h-[90vh] w-full max-w-[360px] overflow-y-auto rounded-3xl border-4 border-blush bg-white p-6 shadow-xl sm:max-w-sm"
          >
            <button onClick={() => setActive(null)} aria-label="Close" className="absolute right-5 top-4 text-sm font-bold text-olive">
              x
            </button>
            <h3 className="pr-6 text-lg font-bold text-crimson">{active.title}</h3>
            <p className="mt-5 text-xs leading-relaxed text-olive">{active.description}</p>
            <p className="mt-4 text-xs text-olive">Technologies:</p>
            <div className="mt-2 flex flex-wrap gap-2">
              {active.tech.map((t) => (
                <span key={t} className="rounded-full bg-[#ff6fb1] px-3 py-1 text-[11px] font-medium text-white">{t}</span>
              ))}
            </div>
            <img src={active.image} alt="" className="mt-4 w-full rounded-md object-cover" />
            <p className="mt-3 text-xs italic text-olive">{active.status}</p>
            {active.link && (
              <a href={active.link.href} target="_blank" rel="noreferrer" className="mt-3 inline-block text-xs text-crimson underline">
                {active.link.label}
              </a>
            )}
          </div>
        </div>
      )}
    </section>
  );
}
