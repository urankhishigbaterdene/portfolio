"use client";
import { useState } from "react";
import { awards } from "@/data/content";
import Flower from "./Flower";

export default function Awards() {
  const [i, setI] = useState(0);
  const a = awards[i];
  const go = (d) => setI((i + d + awards.length) % awards.length);

  return (
    <section id="awards" className="px-6 py-16">
      <h2 className="section-title">Medals & Certificates</h2>
      <p className="mt-2 text-center text-sm">Turn the pages 📖</p>

      <div className="relative mx-auto mt-10 max-w-4xl">
        <div className="cute-card grid overflow-hidden border-4 border-blush bg-[#fff5fa] md:grid-cols-2">
          <div className="flex flex-col items-center justify-center border-b-2 border-dashed border-blush p-6 md:border-b-0 md:border-r-2">
            <img src={a.img} alt={a.title} className="w-full max-w-sm rounded-lg border-4 border-white shadow-md" />
            <p className="mt-3 text-xs text-olive">page {i * 2 + 1}</p>
          </div>
          <div key={i} className="flex origin-left animate-flip flex-col justify-center p-8">
            <span className="mb-3 inline-flex w-fit items-center gap-2 rounded-full bg-gradient-to-r from-[#ffe27a] to-[#ffb3d1] px-4 py-1 text-sm font-bold text-ink">🏅 {a.medal}</span>
            <h3 className="font-logo text-2xl text-cream">{a.title}</h3>
            <p className="mt-3 text-sm leading-relaxed">{a.text}</p>
            <p className="mt-6 text-right text-xs text-olive">page {i * 2 + 2}</p>
          </div>
        </div>
        <Flower size={64} className="absolute -left-5 -top-6 animate-float" />
        <Flower size={54} a="#ffc9e3" b="#ff7eb6" className="absolute -right-4 -bottom-5 animate-float" />
      </div>

      <div className="mt-8 flex items-center justify-center gap-4">
        <button onClick={() => go(-1)} className="pill" aria-label="Previous page">← Prev</button>
        <div className="flex gap-2">
          {awards.map((_, k) => (
            <button key={k} onClick={() => setI(k)} aria-label={`Page ${k + 1}`}
              className={`h-3 w-3 rounded-full border-2 border-white ${k === i ? "bg-sage" : "bg-lav"}`} />
          ))}
        </div>
        <button onClick={() => go(1)} className="pill" aria-label="Next page">Next →</button>
      </div>
    </section>
  );
}
