import { FaInstagram, FaFacebook, FaGithub, FaLinkedin } from "react-icons/fa";
import { footer, site } from "@/data/content";
import Flower from "./Flower";
import Pony from "./Pony";

export default function Footer() {
  const s = site.socials;
  const items = [[FaInstagram, s.instagram, "Instagram"], [FaFacebook, s.facebook, "Facebook"], [FaGithub, s.github, "GitHub"], [FaLinkedin, s.linkedin, "LinkedIn"]];
  return (
    <footer className="relative mt-10 overflow-hidden bg-gradient-to-b from-blush to-lav px-6 pb-8 pt-12 text-center text-sm text-ink">
      <Pony width={110} className="absolute bottom-0 left-4 hidden sm:block" />
      <Pony width={110} body="#ffc9e3" mane="#ff8fbf" className="absolute bottom-0 right-4 hidden -scale-x-100 sm:block" />
      <div className="flex justify-center gap-2"><Flower size={30} /><Flower size={30} a="#ffc9e3" b="#ff7eb6" /><Flower size={30} a="#ffdcea" b="#ff9ec9" /></div>
      <p className="mt-3 font-logo text-2xl text-cream">{site.name}</p>
      <p className="mt-1 text-xs">{footer.line1}</p>
      <p className="text-xs">{footer.line2}</p>
      <div className="mt-5 flex justify-center gap-4">
        {items.map(([Icon, href, label]) => (
          <a key={label} href={href} target="_blank" rel="noreferrer" aria-label={label}
            className="flex h-11 w-11 items-center justify-center rounded-full border-2 border-white bg-white/70 text-xl text-cream shadow transition hover:-translate-y-1 hover:text-sage">
            <Icon />
          </a>
        ))}
      </div>
      <p className="mt-5 text-xs">© {new Date().getFullYear()} {site.name}. Made with 🌸 and 🦄</p>
    </footer>
  );
}
