/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,jsx}", "./components/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        forest: "#ffe8f2", cream: "#d81b78", sage: "#ff4fa3", mint: "#8a3a64",
        card: "#ffffff", ink: "#7a1f4f", olive: "#a24d7b", crimson: "#e91e8c",
        lav: "#ffc9e3", blush: "#ffc2dd", pmint: "#ffe0ee",
      },
      fontFamily: {
        body: ["var(--font-body)", "system-ui", "sans-serif"],
        logo: ["var(--font-logo)", "cursive"],
      },
      keyframes: {
        float: { "0%,100%": { transform: "translateY(0) rotate(var(--r,0deg))" }, "50%": { transform: "translateY(-10px) rotate(var(--r,0deg))" } },
        flip: { from: { transform: "perspective(900px) rotateY(-80deg)", opacity: ".2" }, to: { transform: "perspective(900px) rotateY(0)", opacity: "1" } },
      },
      animation: { float: "float 5s ease-in-out infinite", flip: "flip .5s ease-out" },
    },
  },
  plugins: [],
};
